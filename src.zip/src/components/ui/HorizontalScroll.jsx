import { useEffect, useRef } from "react";

export default function HorizontalScroll({
  scrollRef,
  contentRef,
}) {
  const topRef = useRef(null);

  useEffect(() => {
    const top = topRef.current;
    const scroll = scrollRef.current;
    const content = contentRef.current;

    if (!top || !scroll || !content) return;

    const spacer = top.firstElementChild;

    const update = () => {
      spacer.style.width = `${content.scrollWidth}px`;
    };

    update();

    const resize = new ResizeObserver(update);
    resize.observe(content);

    top.addEventListener("scroll", () => {
      scroll.scrollLeft = top.scrollLeft;
    });

    scroll.addEventListener("scroll", () => {
      top.scrollLeft = scroll.scrollLeft;
    });

    return () => resize.disconnect();
  }, []);

  return (
    <div
      ref={topRef}
      className="overflow-x-auto overflow-y-hidden h-5 mb-2"
    >
      <div style={{ height: 1 }} />
    </div>
  );
}